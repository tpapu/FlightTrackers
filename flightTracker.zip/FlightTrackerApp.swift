//
//  FlightTrackerApp.swift
//  FlightTracker
//
//  A comprehensive flight tracking application that helps users monitor
//  and find the best flight deals with real-time price tracking.
//

import SwiftUI

@main
struct FlightTrackerApp: App {
    @StateObject private var dataManager = DataManager()
    @StateObject private var notificationManager = NotificationManager()
    
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(dataManager)
                .environmentObject(notificationManager)
                .onAppear {
                    // Request notification permissions on app launch
                    notificationManager.requestAuthorization()
                }
        }
    }
}
